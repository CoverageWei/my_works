
# DB DUMP

数据导出工具
## 解决的问题
* 数据库中数据分布不均匀，sqoop的数据导出工具分片严重不均匀

## Features

**数据均衡分片**

* 冷启动时自动对数据进行评估
* 数据分布情况存储在RDS中，下次启动时可以快速分片

**支持多表同时导出**
* 一个MR任务同时导出多个任务，不需要多次申请资源

## 技术实现

使用到的主要框架和服务:

* 使用MapReduce框架，重写RecordReader 和 InputSplit
* 使用Oracle存储数据分片的结果


## 模块详解
* 工具的核心模块，必不可少，工具运行必须的配置
* 用户自定义输出模块： OutputStream 模块， 用户自定义配置，现提供HDFS模式、HIVE模式(Oracle模式待完成)
* 用户自定义分片模块： Splitter 模块

## 使用说明

**参数说明**

* 数据库配置格式 包括数据源和数据分布的中间结果

jdbc.%s.driver   （%s为数据库连接的名称） <br>
jdbc.%s.url <br>
jdbc.%s.user <br>
jdbc.%s.password <br>

example: <br>
jdbc.db.driver=com.netease.backend.db.DBDriver    (此数据库配置的名称为 db,在table配置的时候只需要配置成db即可) <br>
jdbc.db.url=172.17.2.46:8888?key=/home/hadoop/secret.key&logdir=ddb_log${azkaban.job.metadata.file} <br>
jdbc.db.user=* <br>
jdbc.db.password=* <br>

jdbc.metadata.driver=oracle.jdbc.driver.OracleDriver <br>
jdbc.metadata.url=jdbc:oracle:thin:@*:1521:study <br>
jdbc.metadata.user=* <br>
jdbc.metadata.password=* <br>

* 运行环境配置 : azkaban任务的配置

classpath=../../../lib/*   环境配置 <br>

* 核心模块运行配置 : azkaban任务的配置

type=hadoopJava       (azkaban中HadoopJava类型的job) <br>
job.class=com.netease.da.dump.MutliTablesExportJob  (此hadoop任务的运行的类) <br>
method.run=execute  (此hadoop类的启动方法是execute方法) <br>

* 分片和导出模块的系统配置

配置用于自定义的模块的类，非运行配置 <br>
%s.output.class 输出类配置  %s是名称 <br>
%s.splitter.class 分片算法类配置  %s是名称 <br>

example: <br>
hive.output.class=com.netease.da.dump.outputstream.HiveOutputStream     类型名称为hive <br>
hdfs.output.class=com.netease.da.dump.outputstream.HDFSOutputStream     类型名称为hdfs <br>

composite.splitter.class=com.netease.da.dump.splitter.CompositeSplitter  分片算法类， 类型名称为composite <br>


* table源参数配置

由于支持多个表同时导出 ，%s为运行时的task的名称 ，名称必须以table开头，如 table  table.01 table.02 table.100 <br>
%s.src.db  数据库名称 <br>
%s.src.table 数据表 <br>
%s.src.where 数据导出条件 <br>
%s.src.column 数据导出的列 <br>
%s.src.splitnum 数据导出是分片个数 <br>
%s.src.splitid  数据分片的id <br>

注 : src.default.db=db 可以设置默认配置，在不配置table.src.db的情况下，默认为db

example: <br>
table.src.db=db <br>
table.src.table=member <br>
table.src.splitnum=8 <br>
table.src.splitid=id <br>
table.src.column=* <br>

table.01.src.db=db <br>
table.01.src.table=biz_order <br>
table.01.src.splitnum=8 <br>
table.01.src.splitid=id <br>
table.01.src.column=* <br>

* 分片算法类配置

input.default.splitter=composite 默认配置，使得所有的table都默认配置成composite，不需要单独指定 <br>

单独指定每一个表的输出类型的配置 <br>
%s.input.splitter.type <br>

example: <br>
table.input.splitter.type=composite <br>
table.01.input.splitter.type=composite <br>

* 输出类型配置

output.default.type=hive   默认配置,使得所有的table都是默认配置成hive，不需要单独指定 <br>

单独指定每一个表的输出类型的配置 <br>
%s.output.type=hdfs <br>

example: <br>
table.output.type=hdfs <br>
table.01.output.type=hive <br>

* hdfs类型输出配置

多表导出逻辑，数据先输出到临时目录，在从临时目录copy数据到目标路径 <br>

hdfs类型模块必需的配置: <br>
job.output  数据数据的临时路径 <br>

job的使用配置 <br>
%s.output.format : 数据数据格式 ( 可选项 json  csv) <br>
%s.output.delimiter : 数据数据分隔符，用于csv模式 <br>
%s.output.path : 输出路径 <br>

example: <br>
table.output.format=json <br>
table.output.path=/user/da_edu/study/dr/dwu_member_tmp <br>


* hive类型的输出配置

hive类型继承自hdfs类型，hive的独有配置用于替代hdfs类型中的%s.output.path，相较于hdfs类型增加了add partition <br>

hive类型模块必需的配置: <br>
job.output  数据数据的临时路径 <br>
 
%s.des.table : hive 表明 <br>
%s.des.db : hive 库名 <br>
%s.hive.partition.%s : hive表分区名 <br>

example: <br>
table.21.des.table=moc_learn_statistics <br>
table.21.des.db=dr <br>
table.21.hive.partition.day=${job.etl_date} <br>

* 多表配置

table.run=all <br>
默认启动抓取所有的表 <br>
修复数据是 可以设置 table.run=table.02 这样只会跑table.02的数据 <br>

* meta库配置

job.etl.product=edu_etl  在meta库中产品名称 <br>
db.dump.metastore.enabled=true 是否启动metastore库 <br>
table.export.metadata.db=metadata meta库的地址 <br>






